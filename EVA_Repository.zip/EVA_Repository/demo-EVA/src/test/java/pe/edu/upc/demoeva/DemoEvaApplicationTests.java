package pe.edu.upc.demoeva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEvaApplicationTests {

    @Test
    void contextLoads() {
    }

}
