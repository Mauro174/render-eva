package pe.edu.upc.demoeva.entities;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "alertas")
public class Alerta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Relación con Usuario
    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    // Relación con TipoAlerta
    @ManyToOne
    @JoinColumn(name = "tipo_id", nullable = false)
    private TipoAlerta tipo;

    @Column(name = "nivel", length = 10)
    private String nivel;

    @Column(name = "mensaje", columnDefinition = "TEXT")
    private String mensaje;

    // Relación con Usuario como emisor
    @ManyToOne
    @JoinColumn(name = "emisor_id")
    private Usuario emisor;

    @Column(name = "creada", columnDefinition = "TIMESTAMP")
    private LocalDateTime creada;

    public Alerta() {}

    public Alerta(Long id, Usuario usuario, TipoAlerta tipo, String nivel, String mensaje, Usuario emisor, LocalDateTime creada) {
        this.id = id;
        this.usuario = usuario;
        this.tipo = tipo;
        this.nivel = nivel;
        this.mensaje = mensaje;
        this.emisor = emisor;
        this.creada = creada;
    }

    // Getters y setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public TipoAlerta getTipo() { return tipo; }
    public void setTipo(TipoAlerta tipo) { this.tipo = tipo; }

    public String getNivel() { return nivel; }
    public void setNivel(String nivel) { this.nivel = nivel; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    public Usuario getEmisor() { return emisor; }
    public void setEmisor(Usuario emisor) { this.emisor = emisor; }

    public LocalDateTime getCreada() { return creada; }
    public void setCreada(LocalDateTime creada) { this.creada = creada; }
}
